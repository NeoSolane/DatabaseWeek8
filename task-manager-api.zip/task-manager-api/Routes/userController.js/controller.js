const db = require('../db');

exports.createUser = async (req, res) => {
    const { name, email } = req.body;
    try {
        const [result] = await db.execute('INSERT INTO users (name, email) VALUES (?, ?)', [name, email]);
        res.status(201).json({ id: result.insertId, name, email });
    } catch (error) {
        res.status(500).json({ error: 'Database error' });
    }
};

exports.getUsers = async (req, res) => {
    try {
        const [users] = await db.execute('SELECT * FROM users');
        res.json(users);
    } catch (err) {
        res.status(500).json({ error: 'Database error' });
     }
    };