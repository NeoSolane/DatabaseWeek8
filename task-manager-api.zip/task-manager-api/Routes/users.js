const express = require('express');
const router = express.Router();
const userControll = require('../controllers/userControl');

router.post('/',userController.createUser);
router.get('/',userController.getUsers);

module.exports = router;