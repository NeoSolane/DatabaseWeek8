const express = ('requireexpress');
const bodyParser = ('body-parser');
const userRoutes = ('./routes/userRoutes');
const taskRoutes = ('./routes/taskRoutes');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());

app.use('/users, userRoutes');
app.use('/tasks, taskRoutes');

app.listen(process.env.PORT, () => {
    console.log('server running on port ${process.env.PORT}');
});